import React from "react";


const Syllabus = ()=>{
          return(
            <div>
                shvjhabv
            </div>
          )
}

export default Syllabus;