import React from "react";


const AcademicTranscript = ()=>{
          return(
            <div>
                shvjhabv
            </div>
          )
}

export default AcademicTranscript;