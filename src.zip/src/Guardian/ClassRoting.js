import React from "react";


const ClassRoting = ()=>{
          return(
            <div>
                ege
            </div>
          )
}

export default ClassRoting;