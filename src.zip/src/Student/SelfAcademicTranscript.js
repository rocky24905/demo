import React from "react";


const SelfAcademicTranscript = ()=>{
    return(
        <div>sdbvjhsb</div>
    )
}

export default SelfAcademicTranscript;