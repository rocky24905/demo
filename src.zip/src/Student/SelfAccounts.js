import React from "react";


const SelfAccounts = ()=>{
    return(
        <div>sdbvjhsb</div>
    )
}

export default SelfAccounts;