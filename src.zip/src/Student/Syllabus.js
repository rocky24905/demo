import React from "react";


const Syllabus = ()=>{
    return(
        <div>sdbvjhsb</div>
    )
}

export default Syllabus;