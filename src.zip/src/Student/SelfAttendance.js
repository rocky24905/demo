import React from "react";


const SelfAttendance = ()=>{
    return(
        <div>sdbvjhsb</div>
    )
}

export default SelfAttendance;