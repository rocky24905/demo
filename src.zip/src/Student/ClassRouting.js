import React from "react";


const ClassRouting = ()=>{
    return(
        <div>sdbvjhsb</div>
    )
}

export default ClassRouting;