import React from "react";

const Dashbord = ()=>{
    return(
        <div>
            rocky
        </div>
    )
}

export default Dashbord;