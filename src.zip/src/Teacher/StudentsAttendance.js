import React from "react";

const StudentsAttendance = ()=>{
    return(
        <div>
            bven
        </div>
    )
}

export default StudentsAttendance;