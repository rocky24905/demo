import React from "react";

const Syllabus = ()=>{
    return(
        <div>
            bven
        </div>
    )
}

export default Syllabus;