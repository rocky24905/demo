import React from "react";

const ClassRouting = ()=>{
    return(
        <div>
            bven
        </div>
    )
}

export default ClassRouting;