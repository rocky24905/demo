import React from "react";

const AcademicTranscript = ()=>{
    return(
        <div>
            bven
        </div>
    )
}

export default AcademicTranscript;