import React from "react";
import './Teacher.css';

const Teacher = ()=>{
    return(
        <div className="scroll">
            <div className="con">
            <div className="left1"><i class="fa-solid fa-house-chimney"></i><a href="#">Home</a>/ Teacher</div>
              
                <from className="rightee">
                    
                <label htmlFor="role" className="brance"><h3>Brance</h3></label>
                <select id="role" name="role" className="rolee">
                    <option value="brance">xiii</option>
                    <option value="xii">xii</option>
                </select>

                <label htmlFor="role" className="brance"><h3>Sesson</h3></label>
                <select id="role" name="role" className="rolee">
                    <option value="brance">2023</option>
                    <option value="xii">2024</option>
                    <option value="xii">2025</option>
                </select>
                
             </from>
             </div>

             <div className="Teachetype10">
            
            <div className="Teache">
               
               <div className="Teachelist10"><i class="fa-solid fa-list"></i>List</div>

            <div className="Teacheschedule10"><i class="fa-solid fa-circle-plus"></i>Add new Teacher</div>

            </div>
             
             <from className="Teacsearch1011">
               <label htmlFor="role" className="Teacshowsearch1011">Show</label>
               <select id="role" name="role" className="Teacsearone1011">
                 <option value="1">10</option>
                 <option value="1">15</option>
                 <option value="1">20</option>
                 <option value="1">25</option>
               </select>


               <label htmlFor="search" className="Teacshowsearch1011">Search :</label>
               <input type="search" className="Teacsear1011" placeholder="Search"></input>
             </from>
             

            <div className="Teaconestatus1011">
               <div className="Teacstatus1011">

                 <div className="photo11"><b>Photo</b></div>
                 <div className="photo11"><b>Teacher Name</b></div>
                 <div className="photo22"><b>Info</b></div>
                 <div className="photo11"><b>Action</b></div>

                  
                 </div>

                 <div className="crlf">
                   <div className="crlf1">
                    <div className="crlf12"><i class="fa-solid fa-user"></i></div>
                   </div>
                   <div className="crlf1">Ahad Al Nahid</div>
                   <div className="crlf123">
                   Designation : Head Teacher<br></br>
                   Hierarchy : [ Not Provided ]<br></br>
                   Date of birth : 1997-08-04<br></br>
                   Contact no : +8805346547568<br></br>
                   Email : gsimad3@gmail.com<br></br>
                   Attendance device #: [Not provided]
                   </div>
                   <div className="crlf1"></div>
                  
                 </div>

                 <div className="crlf">
                   <div className="crlf1">
                    <div className="crlf12"><i class="fa-solid fa-user"></i></div>
                   </div>
                   <div className="crlf1">Arifa akter</div>
                   <div className="crlf123">
                   Designation : Head Teacher<br></br>
                   Hierarchy : [ Not Provided ]<br></br>
                   Date of birth : 1997-08-04<br></br>
                   Contact no : +8805346547568<br></br>
                   Email : gsimad3@gmail.com<br></br>
                   Attendance device #: [Not provided]
                   </div>
                   <div className="crlf1"></div>
                  
                 </div>

                 <div className="crlf">
                   <div className="crlf1">
                    <div className="crlf12"><i class="fa-solid fa-user"></i></div>
                   </div>
                   <div className="crlf1">Arifa Akter Eva</div>
                   <div className="crlf123">
                   Designation : Head Teacher<br></br>
                   Hierarchy : [ Not Provided ]<br></br>
                   Date of birth : 1997-08-04<br></br>
                   Contact no : +8805346547568<br></br>
                   Email : gsimad3@gmail.com<br></br>
                   Attendance device #: [Not provided]
                   </div>
                   <div className="crlf1"></div>
                  
                 </div>

                 <div className="crlf">
                   <div className="crlf1">
                    <div className="crlf12"><i class="fa-solid fa-user"></i></div>
                   </div>
                   <div className="crlf1">Chandmoni Das</div>
                   <div className="crlf123">
                   Designation : Head Teacher<br></br>
                   Hierarchy : [ Not Provided ]<br></br>
                   Date of birth : 1997-08-04<br></br>
                   Contact no : +8805346547568<br></br>
                   Email : gsimad3@gmail.com<br></br>
                   Attendance device #: [Not provided]
                   </div>
                   <div className="crlf1"></div>
                  
                 </div>

                 <div className="crlf">
                   <div className="crlf1">
                    <div className="crlf12"><i class="fa-solid fa-user"></i></div>
                   </div>
                   <div className="crlf1">Golam Mostofa</div>
                   <div className="crlf123">
                   Designation : Head Teacher<br></br>
                   Hierarchy : [ Not Provided ]<br></br>
                   Date of birth : 1997-08-04<br></br>
                   Contact no : +8805346547568<br></br>
                   Email : gsimad3@gmail.com<br></br>
                   Attendance device #: [Not provided]
                   </div>
                   <div className="crlf1"></div>
                  
                 </div>

                 <div className="crlf">
                   <div className="crlf1">
                    <div className="crlf12"><i class="fa-solid fa-user"></i></div>
                   </div>
                   <div className="crlf1">Md. Kawser Hossen..</div>
                   <div className="crlf123">
                   Designation : Head Teacher<br></br>
                   Hierarchy : [ Not Provided ]<br></br>
                   Date of birth : 1997-08-04<br></br>
                   Contact no : +8805346547568<br></br>
                   Email : gsimad3@gmail.com<br></br>
                   Attendance device #: [Not provided]
                   </div>
                   <div className="crlf1"></div>
                  
                 </div>

                 <div className="crlf">
                   <div className="crlf1">
                    <div className="crlf12"><i class="fa-solid fa-user"></i></div>
                   </div>
                   <div className="crlf1">Rabia Akter</div>
                   <div className="crlf123">
                   Designation : Head Teacher<br></br>
                   Hierarchy : [ Not Provided ]<br></br>
                   Date of birth : 1997-08-04<br></br>
                   Contact no : +8805346547568<br></br>
                   Email : gsimad3@gmail.com<br></br>
                   Attendance device #: [Not provided]
                   </div>
                   <div className="crlf1"></div>
                  
                 </div>

                 <div className="crlf">
                   <div className="crlf1">
                    <div className="crlf12"><i class="fa-solid fa-user"></i></div>
                   </div>
                   <div className="crlf1">Rashedul Islam</div>
                   <div className="crlf123">
                   Designation : Head Teacher<br></br>
                   Hierarchy : [ Not Provided ]<br></br>
                   Date of birth : 1997-08-04<br></br>
                   Contact no : +8805346547568<br></br>
                   Email : gsimad3@gmail.com<br></br>
                   Attendance device #: [Not provided]
                   </div>
                   <div className="crlf1"></div>
                  
                 </div>

                 <div className="crlf">
                   <div className="crlf1">
                    <div className="crlf12"><i class="fa-solid fa-user"></i></div>
                   </div>
                   <div className="crlf1">Saida arifen sriti</div>
                   <div className="crlf123">
                   Designation : Head Teacher<br></br>
                   Hierarchy : [ Not Provided ]<br></br>
                   Date of birth : 1997-08-04<br></br>
                   Contact no : +8805346547568<br></br>
                   Email : gsimad3@gmail.com<br></br>
                   Attendance device #: [Not provided]
                   </div>
                   <div className="crlf1"></div>
                  
                 </div>

                 <div className="Teacstatus1011">

                   <div className="photo11"><b>Photo</b></div>
                   <div className="photo11"><b>Teacher Name</b></div>
                   <div className="photo22"><b>Info</b></div>
                   <div className="photo11"><b>Action</b></div>

                </div>
     
                 </div>
               
                 <div className="Teacshowing1011">
                   <div className="Teacshowings1011">Showing 1 to 7 of 7 entries</div>
                   <div className="Teacprevious1011">
                     <div className="Teacnext1011">Previous</div>
                     <div className="Teacnext44">1</div>
                     <div className="Teacnext1011">Next</div>
                   </div>
                 </div>
                 <div className="node">
                    <div className="nodeone">© 2025</div>
                 </div>
             </div>
             

           
        </div>
    )
}

export default Teacher;