import React from "react";
import './Guardians.css';

const Guardians = ()=>{
    return(
        <div className="scroll">
            <div className="con">
            <div className="left1"><i class="fa-solid fa-house-chimney"></i><a href="#">Home</a>/ Guardian</div>
              
                <from className="rightee">
                    
                <label htmlFor="role" className="brance"><h3>Brance</h3></label>
                <select id="role" name="role" className="rolee">
                    <option value="brance">xiii</option>
                    <option value="xii">xii</option>
                </select>

                <label htmlFor="role" className="brance"><h3>Sesson</h3></label>
                <select id="role" name="role" className="rolee">
                    <option value="brance">2023</option>
                    <option value="xii">2024</option>
                    <option value="xii">2025</option>
                </select>
                
             </from>
             </div>

             <div className="Guardianstype10">
            
            <div className="Guardians">
               
               <div className="Guardianslist10"><i class="fa-solid fa-list"></i>List</div>

            <div className="Guardiansschedule10"><i class="fa-solid fa-circle-plus"></i>Add new Guardian</div>

            </div>
             
             <from className="Guardiansearch1011">
               <label htmlFor="role" className="Guardianshowsearch1011">Show</label>
               <select id="role" name="role" className="Guardiansearone1011">
                 <option value="1">10</option>
                 <option value="1">15</option>
                 <option value="1">20</option>
                 <option value="1">25</option>
               </select>


               <label htmlFor="search" className="Guardianshowsearch1011">Search :</label>
               <input type="search" className="Guardiansear1011" placeholder="Search"></input>
             </from>
             

            <div className="Guardianonestatus1011">
               <div className="Guardianstatus1011">

                 <div className="photologo11"><b>Photo</b></div>
                 <div className="photologo11"><b>Guardian's name</b></div>
                 <div className="photologo22"><b>Info</b></div>
                 <div className="photologo11"><b>Action</b></div>
 
                 </div>

                 <div className="used">
                   <div className="useds">
                    <div className="used1"><i class="fa-solid fa-user"></i></div>
                   </div>
                   <div className="useds">Sathi Akter</div>
                   <div className="used2">
                   Occupation : Service<br></br>
                   Contact no : +8801772970648<br></br>
                   Email : [Not provided]
                   </div>
                   <div className="useds"></div>
                  
                 </div>

                 <div className="used">
                   <div className="useds">
                    <div className="used1"><i class="fa-solid fa-user"></i></div>
                   </div>
                   <div className="useds">Abdul Malek</div>
                   <div className="used2">
                   Occupation : Service<br></br>
                   Contact no : +8801772970648<br></br>
                   Email : [Not provided]
                   </div>
                   <div className="useds"></div>
                  
                 </div>

                 <div className="used">
                   <div className="useds">
                    <div className="used1"><i class="fa-solid fa-user"></i></div>
                   </div>
                   <div className="useds">Abdul Malek</div>
                   <div className="used2">
                   Occupation : Service<br></br>
                   Contact no : +8801772970648<br></br>
                   Email : [Not provided]
                   </div>
                   <div className="useds"></div>
                  
                 </div>

                 <div className="used">
                   <div className="useds">
                    <div className="used1"><i class="fa-solid fa-user"></i></div>
                   </div>
                   <div className="useds">Abdur Rajjak</div>
                   <div className="used2">
                   Occupation : Service<br></br>
                   Contact no : +8801772970648<br></br>
                   Email : [Not provided]
                   </div>
                   <div className="useds"></div>
                  
                 </div>

                 <div className="used">
                   <div className="useds">
                    <div className="used1"><i class="fa-solid fa-user"></i></div>
                   </div>
                   <div className="useds">Abdur Razzak</div>
                   <div className="used2">
                   Occupation : Service<br></br>
                   Contact no : +8801772970648<br></br>
                   Email : [Not provided]
                   </div>
                   <div className="useds"></div>
                  
                 </div>

                 <div className="used">
                   <div className="useds">
                    <div className="used1"><i class="fa-solid fa-user"></i></div>
                   </div>
                   <div className="useds">Abu Kalam</div>
                   <div className="used2">
                   Occupation : Service<br></br>
                   Contact no : +8801772970648<br></br>
                   Email : [Not provided]
                   </div>
                   <div className="useds"></div>
                  
                 </div>

                 <div className="used">
                   <div className="useds">
                    <div className="used1"><i class="fa-solid fa-user"></i></div>
                   </div>
                   <div className="useds">Adhin</div>
                   <div className="used2">
                   Occupation : Service<br></br>
                   Contact no : +8801772970648<br></br>
                   Email : [Not provided]
                   </div>
                   <div className="useds"></div>
                  
                 </div>

                 <div className="used">
                   <div className="useds">
                    <div className="used1"><i class="fa-solid fa-user"></i></div>
                   </div>
                   <div className="useds">Akbor Ali</div>
                   <div className="used2">
                   Occupation : Service<br></br>
                   Contact no : +8801772970648<br></br>
                   Email : [Not provided]
                   </div>
                   <div className="useds"></div>
                  
                 </div>

                 <div className="used">
                   <div className="useds">
                    <div className="used1"><i class="fa-solid fa-user"></i></div>
                   </div>
                   <div className="useds">Alam Hossen</div>
                   <div className="used2">
                   Occupation : Service<br></br>
                   Contact no : +8801772970648<br></br>
                   Email : [Not provided]
                   </div>
                   <div className="useds"></div>
                  
                 </div>

                 <div className="used">
                   <div className="useds">
                    <div className="used1"><i class="fa-solid fa-user"></i></div>
                   </div>
                   <div className="useds">Alamgir Hossen</div>
                   <div className="used2">
                   Occupation : Service<br></br>
                   Contact no : +8801772970648<br></br>
                   Email : [Not provided]
                   </div>
                   <div className="useds"></div>
                  
                 </div>

                 <div className="used">
                   <div className="useds">
                    <div className="used1"><i class="fa-solid fa-user"></i></div>
                   </div>
                   <div className="useds">Abdul Lotif</div>
                   <div className="used2">
                   Occupation : Service<br></br>
                   Contact no : +8801772970648<br></br>
                   Email : [Not provided]
                   </div>
                   <div className="useds"></div>
                  
                 </div>

                 <div className="used">
                   <div className="useds">
                    <div className="used1"><i class="fa-solid fa-user"></i></div>
                   </div>
                   <div className="useds">Abdul Lotif</div>
                   <div className="used2">
                   Occupation : Service<br></br>
                   Contact no : +8801772970648<br></br>
                   Email : [Not provided]
                   </div>
                   <div className="useds"></div>
                  
                 </div>

                 <div className="Guardianstatus1011">

                 <div className="photologo11"><b>Photo</b></div>
                 <div className="photologo11"><b>Guardian's name</b></div>
                 <div className="photologo22"><b>Info</b></div>
                 <div className="photologo11"><b>Action</b></div>
 
                 </div>
     
                 </div>
               
                 <div className="Guardianshowing1011">
                   <div className="Guardianshowings1011">Showing 1 to 7 of 7 entries</div>
                   <div className="Guardianprevious1011">
                     <div className="Guardiannext1011">Previous</div>
                     <div className="Guardiannext44">1</div>
                     <div className="Guardiannext1011">Next</div>
                   </div>
                 </div>
                 <div className="node">
                    <div className="nodeone">© 2025</div>
                 </div>
             </div>
             

             
        </div>
    )
}

export default Guardians;