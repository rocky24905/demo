import React from "react";
import './Gradasetup.css';

const Gradasetup = ()=>{
   return(
    <div className="scroll">
   <div className="con">
            <div className="left1"><i class="fa-solid fa-house-chimney"></i><a href="#">Home</a>/ Grada Setup</div>
              
                <from className="rightee">
                    
                <label htmlFor="role" className="brance"><h3>Brance</h3></label>
                <select id="role" name="role" className="rolee">
                    <option value="brance">xiii</option>
                    <option value="xii">xii</option>
                </select>

                <label htmlFor="role" className="brance"><h3>Sesson</h3></label>
                <select id="role" name="role" className="rolee">
                    <option value="brance">2023</option>
                    <option value="xii">2024</option>
                    <option value="xii">2025</option>
                </select>
                
             </from>
             </div>


             <div className="Gradatype10">
            
             <div className="Grada">
                
                <div className="Gradalist10"><i class="fa-solid fa-list"></i>List</div>

             <div className="Gradaschedule10"><i class="fa-solid fa-circle-plus"></i>Add new grade</div>

             </div>
              
              <from className="setupsearch1011">
                <label htmlFor="role" className="setupshowsearch1011">Show</label>
                <select id="role" name="role" className="setupsearone1011">
                  <option value="1">10</option>
                  <option value="1">15</option>
                  <option value="1">20</option>
                  <option value="1">25</option>
                </select>


                <label htmlFor="search" className="setupshowsearch1011">Search :</label>
                <input type="search" className="setupsear1011" placeholder="Search"></input>
              </from>
              

             <div className="setuponestatus1011">
                <div className="setupstatus1011">

                  <div className="Interval"><b>Grade name</b></div>
                  <div className="Interval1"><b>Grade point</b></div>
                  <div className="Interval2"><b>Interval</b></div>
                  <div className="Interval3"><b>Grade type</b></div>
                  <div className="Interval3"><b>Status</b></div>
                  <div className="Interval3"><b>Action</b></div>
                   
                  </div>

                  <div className="aa">
                    <div className="a">A+</div>
                    <div className="a">5.00</div>
                    <div className="a">80 - 100</div>
                    <div className="ab"><div className="cc"><b>Pass grade</b></div></div>
                    <div className="a"></div>
                    <div className="a"></div>
                  </div>

                  <div className="aa">
                    <div className="a">A+</div>
                    <div className="a">5.00</div>
                    <div className="a">80 - 100</div>
                    <div className="ab"><div className="cc"><b>Pass grade</b></div></div>
                    <div className="a"></div>
                    <div className="a"></div>
                  </div>

                  <div className="aa">
                    <div className="a">A+</div>
                    <div className="a">5.00</div>
                    <div className="a">80 - 100</div>
                    <div className="ab"><div className="cc"><b>Pass grade</b></div></div>
                    <div className="a"></div>
                    <div className="a"></div>
                  </div>

                  <div className="aa">
                    <div className="a">F</div>
                    <div className="a">0.00</div>
                    <div className="a">0 - 33</div>
                    <div className="ab"><div className="cc1"><b>Fail grade</b></div></div>
                    <div className="a"></div>
                    <div className="a"></div>
                  </div>

                  <div className="aa">
                    <div className="a">A+</div>
                    <div className="a">5.00</div>
                    <div className="a">80 - 100</div>
                    <div className="ab"><div className="cc"><b>Pass grade</b></div></div>
                    <div className="a"></div>
                    <div className="a"></div>
                  </div>

                  <div className="aa">
                    <div className="a">A+</div>
                    <div className="a">5.00</div>
                    <div className="a">80 - 100</div>
                    <div className="ab"><div className="cc"><b>Pass grade</b></div></div>
                    <div className="a"></div>
                    <div className="a"></div>
                  </div>

                  <div className="aa">
                    <div className="a">F</div>
                    <div className="a">0.00</div>
                    <div className="a">0 - 33</div>
                    <div className="ab"><div className="cc1"><b>Fail grade</b></div></div>
                    <div className="a"></div>
                    <div className="a"></div>
                  </div>

                  <div className="aa">
                    <div className="a">A+</div>
                    <div className="a">5.00</div>
                    <div className="a">80 - 100</div>
                    <div className="ab"><div className="cc"><b>Pass grade</b></div></div>
                    <div className="a"></div>
                    <div className="a"></div>
                  </div>

                  <div className="aa">
                    <div className="a">A+</div>
                    <div className="a">5.00</div>
                    <div className="a">80 - 100</div>
                    <div className="ab"><div className="cc"><b>Pass grade</b></div></div>
                    <div className="a"></div>
                    <div className="a"></div>
                  </div>

                  <div className="aa">
                    <div className="a">A+</div>
                    <div className="a">5.00</div>
                    <div className="a">80 - 100</div>
                    <div className="ab"><div className="cc"><b>Pass grade</b></div></div>
                    <div className="a"></div>
                    <div className="a"></div>
                  </div>

                  <div className="aa">
                    <div className="a">F</div>
                    <div className="a">0.00</div>
                    <div className="a">0 - 33</div>
                    <div className="ab"><div className="cc1"><b>Fail grade</b></div></div>
                    <div className="a"></div>
                    <div className="a"></div>
                  </div>

                  <div className="aa">
                    <div className="a">A+</div>
                    <div className="a">5.00</div>
                    <div className="a">80 - 100</div>
                    <div className="ab"><div className="cc"><b>Pass grade</b></div></div>
                    <div className="a"></div>
                    <div className="a"></div>
                  </div>
      
                  </div>
                
                  <div className="setupshowing1011">
                    <div className="setupshowings1011">Showing 1 to 7 of 7 entries</div>
                    <div className="setupprevious1011">
                      <div className="setupnext1011">Previous</div>
                      <div className="setnext44">1</div>
                      <div className="setupnext1011">Next</div>
                    </div>
                  </div>
                  <div className="node">
                    <div className="nodeone">© 2025</div>
                 </div>
              </div>
              

         
    </div>
   )
}

export default Gradasetup;